shell variables expansions
