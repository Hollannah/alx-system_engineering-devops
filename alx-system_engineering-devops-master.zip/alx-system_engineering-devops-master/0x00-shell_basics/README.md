shell basics
