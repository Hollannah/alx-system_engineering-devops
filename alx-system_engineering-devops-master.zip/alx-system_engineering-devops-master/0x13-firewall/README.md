# 0x13. Firewall
## Description
What you should learn from this project:

### 0.  Block all incoming traffic but
* Let’s install the ufw firewall and setup a few rules on web-01.
### 1. Port forwarding
* Firewalls can not only filter requests, they can also forward them.
## Author
  * Olaide Hannah - Hollannah
