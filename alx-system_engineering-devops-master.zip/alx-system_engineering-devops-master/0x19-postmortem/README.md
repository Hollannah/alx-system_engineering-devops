# 0x19. Postmortem

## Description
What you should learn from this project:

---

### [0. My first postmortem](./README.md)
* b''


### [1. Make people want to read your postmortem](./README.md)
* b'We are constantly stormed by a quantity of information, it\xe2\x80\x99s tough to get people to read you.'

---

## Author
* **Olaide Hannah** - [hollannah](https://github.com/hollannah)
